from kivy.lang import Builder
from kivy.app import App
from kivy.uix.image import Image
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.slider import Slider
from kivy.uix.switch import Switch
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.animation import Animation
from kivy.graphics.texture import Texture
from kivy.properties import StringProperty, NumericProperty, BooleanProperty, ObjectProperty
import requests
import threading
import re
import os
import base64
from datetime import datetime
from PIL import Image as PILImage
import io
import shutil

# Android TTS, Connectivity, Intent, PackageManager
ANDROID_PLATFORM = False
try:
    from jnius import autoclass
    PythonActivity = autoclass('org.kivy.android.PythonActivity')
    Activity = PythonActivity.mActivity
    TTS = autoclass('android.speech.tts.TextToSpeech')
    Locale = autoclass('java.util.Locale')
    ConnectivityManager = autoclass('android.net.ConnectivityManager')
    Context = autoclass('android.content.Context')
    Intent = autoclass('android.content.Intent')
    PackageManager = autoclass('android.content.pm.PackageManager')
    ANDROID_PLATFORM = True
except ImportError:
    pass

# Dark Black Background
Window.clearcolor = (0.05, 0.05, 0.05, 1)

EMBLEM = "stinky_emblem.png" 
PERSONALITY_FILE = "StinkyPersonality.txt"

# Modern, clean mobile app UI with Purple, Black, and Cyan
KV = '''
#:import FadeTransition kivy.uix.screenmanager.FadeTransition
#:import get_color_from_hex kivy.utils.get_color_from_hex

<MessageBubble@BoxLayout>:
    message_text: ""
    is_user: False
    size_hint_y: None
    height: message_label.texture_size[1] + dp(24)
    padding: 0
    spacing: 0
    
    Widget:
        size_hint_x: 0.15 if root.is_user else None
        width: 0 if not root.is_user else dp(60)
    
    BoxLayout:
        size_hint_x: None
        width: min(dp(280), message_label.texture_size[0] + dp(32))
        padding: dp(16), dp(12)
        canvas.before:
            Color:
                # Purple for user, Dark Grey/Cyan for bot
                rgba: get_color_from_hex('#7B2CBF') if root.is_user else get_color_from_hex('#1A1A1A')
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(18), dp(18), dp(4) if root.is_user else dp(18), dp(18) if root.is_user else dp(4)]
            Color:
                rgba: get_color_from_hex('#00E5FF') if not root.is_user else (0,0,0,0)
            Line:
                width: dp(1)
                rounded_rectangle: (self.x, self.y, self.width, self.height, dp(18), dp(18), dp(4) if root.is_user else dp(18), dp(18) if root.is_user else dp(4))
        
        Label:
            id: message_label
            text: root.message_text
            color: (1, 1, 1, 1)
            font_size: '15sp'
            size_hint: None, None
            size: self.texture_size
            text_size: dp(248), None
            markup: True
    
    Widget:
        size_hint_x: 0.15 if not root.is_user else None
        width: 0 if root.is_user else dp(60)

<TopBar@BoxLayout>:
    size_hint_y: None
    height: dp(56)
    padding: dp(16), dp(8)
    spacing: dp(12)
    canvas.before:
        Color:
            rgba: 0, 0, 0, 1
        Rectangle:
            pos: self.pos
            size: self.size
        Color:
            rgba: get_color_from_hex('#00E5FF')
        Rectangle:
            pos: self.x, self.y
            size: self.width, dp(1)

<ActionButton@Button>:
    size_hint_y: None
    height: dp(44)
    background_normal: ''
    background_color: 0, 0, 0, 0
    font_size: '15sp'
    color: get_color_from_hex('#00E5FF')
    canvas.before:
        Color:
            rgba: get_color_from_hex('#240046')
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]

<SettingsCard@BoxLayout>:
    size_hint_y: None
    height: dp(56)
    padding: dp(16), dp(12)
    spacing: dp(12)
    canvas.before:
        Color:
            rgba: get_color_from_hex('#121212')
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(12)]

# --- LOGIN SCREEN ---
<LoginScreen>:
    name: "login"
    FloatLayout:
        canvas.before:
            Color:
                rgba: 0, 0, 0, 1
            Rectangle:
                pos: self.pos
                size: self.size

        BoxLayout:
            orientation: 'vertical'
            size_hint: 0.85, None
            height: dp(420)
            pos_hint: {'center_x': 0.5, 'center_y': 0.5}
            spacing: dp(24)
            padding: dp(20)

            # App Icon
            FloatLayout:
                size_hint_y: None
                height: dp(100)
                
                Widget:
                    size_hint: None, None
                    size: dp(100), dp(100)
                    pos_hint: {'center_x': 0.5, 'center_y': 0.5}
                    canvas.before:
                        Color:
                            rgba: get_color_from_hex('#7B2CBF')
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [dp(22)]
                        Color:
                            rgba: get_color_from_hex('#00E5FF')
                        Line:
                            width: dp(1.5)
                            rounded_rectangle: (self.x, self.y, self.width, self.height, dp(22))
                    
                    Image:
                        source: app.emblem_image
                        size_hint: None, None
                        size: dp(60), dp(60)
                        pos_hint: {'center_x': 0.5, 'center_y': 0.5}

            Label:
                text: "07stinky bot"
                font_size: '32sp'
                color: get_color_from_hex('#00E5FF')
                bold: True
                size_hint_y: None
                height: dp(40)

            Label:
                text: "Stay smelly, stay smart"
                font_size: '16sp'
                color: get_color_from_hex('#9D4EDD')
                size_hint_y: None
                height: dp(24)

            # Modern text input
            BoxLayout:
                size_hint_y: None
                height: dp(50)
                canvas.before:
                    Color:
                        rgba: get_color_from_hex('#1A1A1A')
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(12)]
                    Color:
                        rgba: get_color_from_hex('#00E5FF')
                    Line:
                        rounded_rectangle: (self.x, self.y, self.width, self.height, dp(12))
                        width: dp(1)
                
                TextInput:
                    id: username_input
                    hint_text: "Who are you?"
                    multiline: False
                    background_color: 0, 0, 0, 0
                    foreground_color: 1, 1, 1, 1
                    cursor_color: get_color_from_hex('#00E5FF')
                    padding: dp(16), dp(15)
                    font_size: '16sp'
                    hint_text_color: 0.4, 0.4, 0.4, 1
                    on_text_validate: app.authenticate_user(self.text)

            Button:
                text: "ENTER"
                size_hint_y: None
                height: dp(50)
                background_normal: ''
                background_color: 0, 0, 0, 0
                font_size: '17sp'
                bold: True
                color: 1, 1, 1, 1
                on_release: app.authenticate_user(username_input.text)
                canvas.before:
                    Color:
                        rgba: get_color_from_hex('#7B2CBF')
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(12)]

# --- CHAT SCREEN ---
<ChatScreen>:
    name: "chat"
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0, 0, 0, 1
            Rectangle:
                pos: self.pos
                size: self.size

        # Top Navigation Bar
        TopBar:
            Button:
                text: "☰"
                size_hint_x: None
                width: dp(40)
                background_normal: ''
                background_color: 0, 0, 0, 0
                font_size: '24sp'
                color: get_color_from_hex('#00E5FF')
                on_release: app.toggle_menu()
            
            Label:
                text: "07stinky bot"
                font_size: '18sp'
                bold: True
                color: 1, 1, 1, 1
                size_hint_x: 1
            
            Widget:
                size_hint: None, None
                size: dp(12), dp(12)
                pos_hint: {'center_x': 0.5, 'center_y': 0.5}
                canvas.before:
                    Color:
                        rgba: get_color_from_hex('#00E5FF') if app.is_online() else get_color_from_hex('#FF0055')
                    Ellipse:
                        pos: self.pos
                        size: self.size

        # Chat Area
        ScrollView:
            id: chat_scroll
            do_scroll_x: False
            
            BoxLayout:
                id: chat_history
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                spacing: dp(12)
                padding: dp(16), dp(12)

        # Input Area
        BoxLayout:
            size_hint_y: None
            height: max(dp(64), input_field.minimum_height + dp(24))
            padding: dp(12), dp(12)
            spacing: dp(8)
            canvas.before:
                Color:
                    rgba: 0, 0, 0, 1
                Rectangle:
                    pos: self.pos
                    size: self.size
                Color:
                    rgba: get_color_from_hex('#7B2CBF')
                Rectangle:
                    pos: self.x, self.y + self.height - dp(1)
                    size: self.width, dp(1)
            
            BoxLayout:
                size_hint_x: 1
                padding: dp(12), dp(8)
                canvas.before:
                    Color:
                        rgba: get_color_from_hex('#1A1A1A')
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(20)]
                    Color:
                        rgba: get_color_from_hex('#00E5FF')
                    Line:
                        width: dp(1)
                        rounded_rectangle: (self.x, self.y, self.width, self.height, dp(20))
                
                TextInput:
                    id: input_field
                    hint_text: "Say something stinky..."
                    hint_text_color: 0.4, 0.4, 0.4, 1
                    multiline: True
                    size_hint_y: None
                    height: max(dp(24), self.minimum_height)
                    background_color: 0, 0, 0, 0
                    foreground_color: 1, 1, 1, 1
                    cursor_color: get_color_from_hex('#00E5FF')
                    font_size: '16sp'
                    padding: 0
                    on_text_validate: app.send_message()
            
            Button:
                text: ">"
                size_hint: None, None
                size: dp(40), dp(40)
                background_normal: ''
                background_color: 0, 0, 0, 0
                font_size: '20sp'
                bold: True
                color: 0, 0, 0, 1
                on_release: app.send_message()
                canvas.before:
                    Color:
                        rgba: get_color_from_hex('#00E5FF')
                    Ellipse:
                        pos: self.pos
                        size: self.size

        # Side Menu (Purple Theme)
        FloatLayout:
            id: menu_overlay
            opacity: 0
            disabled: True
            
            Widget:
                canvas.before:
                    Color:
                        rgba: 0, 0, 0, 0.7
                    Rectangle:
                        pos: self.pos
                        size: self.size
                on_touch_down: if self.collide_point(*args[1].pos): app.toggle_menu()
            
            BoxLayout:
                id: menu_panel
                orientation: 'vertical'
                size_hint: 0.75, 1
                pos_hint: {'x': -0.75, 'y': 0}
                padding: dp(20), dp(60), dp(20), dp(20)
                spacing: dp(15)
                canvas.before:
                    Color:
                        rgba: get_color_from_hex('#10002B')
                    Rectangle:
                        pos: self.pos
                        size: self.size
                    Color:
                        rgba: get_color_from_hex('#00E5FF')
                    Line:
                        points: [self.right, self.top, self.right, self.y]
                        width: dp(1.5)
                
                # User Profile Section
                BoxLayout:
                    size_hint_y: None
                    height: dp(80)
                    spacing: dp(12)
                    
                    Widget:
                        size_hint: None, None
                        size: dp(60), dp(60)
                        canvas.before:
                            Color:
                                rgba: get_color_from_hex('#00E5FF')
                            Ellipse:
                                pos: self.pos
                                size: self.size
                        
                        Label:
                            text: app.current_username[0].upper() if app.current_username else "?"
                            font_size: '28sp'
                            bold: True
                            color: 0, 0, 0, 1
                            pos_hint: {'center_x': 0.5, 'center_y': 0.5}
                    
                    BoxLayout:
                        orientation: 'vertical'
                        Label:
                            text: app.current_username
                            font_size: '18sp'
                            bold: True
                            color: 1, 1, 1, 1
                            halign: 'left'
                            text_size: self.size
                        Label:
                            text: "Online"
                            font_size: '14sp'
                            color: get_color_from_hex('#00E5FF')
                            halign: 'left'
                            text_size: self.size

                ScrollView:
                    BoxLayout:
                        orientation: 'vertical'
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(10)
                        
                        Label:
                            text: "BOT MODES"
                            font_size: '12sp'
                            bold: True
                            color: 0.6, 0.6, 0.6, 1
                            size_hint_y: None
                            height: dp(30)
                        
                        ActionButton:
                            text: "⚡ Stinky Quick"
                            on_release: app.set_ai_mode('nix')
                        ActionButton:
                            text: "🧠 Deep Stink"
                            on_release: app.set_ai_mode('blub')
                        ActionButton:
                            text: "🤖 Standard"
                            on_release: app.set_ai_mode('default')
                        
                        Widget:
                            size_hint_y: None
                            height: dp(20)
                            
                        ActionButton:
                            text: "🧹 Clear Chat"
                            on_release: app.clear_chat()
                        ActionButton:
                            text: "🚪 Leave"
                            color: get_color_from_hex('#FF0055')
                            on_release: app.logout()

ScreenManager:
    transition: FadeTransition()
    LoginScreen:
    ChatScreen:
'''

class LoginScreen(Screen):
    pass

class ChatScreen(Screen):
    pass

class CyanixApp(App): # Keep class name or rename to StinkyApp
    emblem_image = StringProperty(EMBLEM)
    status_text = StringProperty("• ONLINE")
    status_expanded = BooleanProperty(False)
    system_info_text = StringProperty("")
    auto_speak_enabled = BooleanProperty(True)
    menu_open = BooleanProperty(False)
    
    current_username = StringProperty("Unknown")
    current_memory_file = StringProperty("")
    current_mode = StringProperty("default")
    
    # Same Keys
    GROQ_KEYS = [""]
    OPENAI_KEYS = ["sk-proj-your-key-here"]
    GEMINI_KEYS = [""]
    XAI_KEYS = [""]
    
    current_groq_index = NumericProperty(0)
    current_openai_index = NumericProperty(0)
    current_gemini_index = NumericProperty(0)
    current_xai_index = NumericProperty(0)

    def build(self):
        self.title = "07stinky bot"
        if not os.path.exists(EMBLEM):
            # Fallback graphic for the emblem
            pass

        self.load_personality()
        
        if ANDROID_PLATFORM:
            try:
                self.tts = TTS(Activity, None)
                self.tts.setLanguage(Locale.US)
                self.tts.setSpeechRate(0.9)
                self.cm = Activity.getSystemService(Context.CONNECTIVITY_SERVICE)
                self.pm = Activity.getPackageManager()
                self.intent_filter = autoclass('android.content.IntentFilter')(autoclass('android.content.Intent').ACTION_BATTERY_CHANGED)
                Window.softinput_mode = 'pan'
            except Exception as e:
                print(f"Android init error: {e}")
        
        self.update_system_info()
        return Builder.load_string(KV)

    def get_chat_screen_ids(self):
        return self.root.get_screen('chat').ids

    def toggle_menu(self):
        chat_ids = self.get_chat_screen_ids()
        if not chat_ids: return
        menu_overlay = chat_ids.menu_overlay
        menu_panel = chat_ids.menu_panel
        
        if self.menu_open:
            anim_panel = Animation(pos_hint={'x': -0.75, 'y': 0}, duration=0.3, t='out_quad')
            anim_overlay = Animation(opacity=0, duration=0.3)
            anim_panel.start(menu_panel)
            anim_overlay.start(menu_overlay)
            anim_overlay.bind(on_complete=lambda *args: setattr(menu_overlay, 'disabled', True))
            self.menu_open = False
        else:
            menu_overlay.disabled = False
            anim_panel = Animation(pos_hint={'x': 0, 'y': 0}, duration=0.3, t='out_quad')
            anim_overlay = Animation(opacity=1, duration=0.3)
            anim_panel.start(menu_panel)
            anim_overlay.start(menu_overlay)
            self.menu_open = True

    def authenticate_user(self, username):
        username = username.strip()
        if not username: return
        self.current_username = username
        safe_username = "".join(x for x in username if x.isalnum())
        self.current_memory_file = f"StinkyMem_{safe_username}.txt"
        
        if not os.path.exists(self.current_memory_file):
            with open(self.current_memory_file, "w", encoding="utf-8") as f:
                f.write(f"System: 07stinky bot initialized for {username} at {datetime.now()}\n\n")

        self.root.current = "chat"
        self.load_conversation_history()
        Clock.schedule_once(lambda dt: self.greet_user(username), 1)

    def greet_user(self, username):
        msg = f"Yo {username}! 07stinky bot is online. What's the plan?"
        self.add_message_bubble(msg, is_user=False)
        if self.auto_speak_enabled and ANDROID_PLATFORM:
            self.speak(msg)

    def logout(self):
        self.root.current = "login"
        if self.menu_open: self.toggle_menu()

    def add_message_bubble(self, text, is_user=False):
        from kivy.factory import Factory
        bubble = Factory.MessageBubble()
        bubble.message_text = text
        bubble.is_user = is_user
        chat_ids = self.get_chat_screen_ids()
        if chat_ids:
            chat_ids.chat_history.add_widget(bubble)
            Clock.schedule_once(lambda dt: setattr(chat_ids.chat_scroll, 'scroll_y', 0), 0.1)

    def send_message(self):
        chat_ids = self.get_chat_screen_ids()
        user_input = chat_ids.input_field.text.strip()
        if not user_input: return

        self.add_message_bubble(user_input, is_user=True)
        self.save_to_memory("You", user_input)
        chat_ids.input_field.text = ""
        threading.Thread(target=self.process_query, args=(user_input,), daemon=True).start()

    def process_query(self, user_input):
        system_prompt = f"You are 07stinky bot. You are talking to {self.current_username}. Be helpful but have a cool, tech-focused personality."
        # Use existing logic for API calls...
        # [Simplified for space, same as your original logic]
        context_messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_input}]
        
        # Choosing provider
        prov = "groq"
        model = "llama-3.1-8b-instant"
        ai_text = self._make_api_call(prov, model, context_messages, 0.7, 1024)
        
        Clock.schedule_once(lambda dt: self.deliver_response(ai_text))

    def _make_api_call(self, provider, model, messages, temperature, max_tokens):
        # Your original API logic remains here...
        try:
            api_key = self.GROQ_KEYS[0]
            url = "https://api.groq.com/openai/v1/chat/completions"
            headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
            payload = {"model": model, "messages": messages, "temperature": temperature, "max_tokens": max_tokens}
            response = requests.post(url, headers=headers, json=payload, timeout=20)
            return response.json()["choices"][0]["message"]["content"].strip()
        except:
            return "Connection error. 07stinky bot is struggling to reach the web."

    def deliver_response(self, ai_text):
        self.add_message_bubble(ai_text, is_user=False)
        self.save_to_memory("07stinky bot", ai_text)
        if self.auto_speak_enabled and ANDROID_PLATFORM:
            self.speak(ai_text)

    def save_to_memory(self, sender, text):
        if not self.current_memory_file: return
        with open(self.current_memory_file, "a", encoding="utf-8") as f:
            f.write(f"{sender}: {text}\n\n")

    def load_conversation_history(self):
        if not os.path.exists(self.current_memory_file): return
        with open(self.current_memory_file, "r", encoding="utf-8") as f:
            content = f.read()
            for line in content.strip().split("\n\n")[-10:]:
                if "You:" in line: self.add_message_bubble(line.replace("You:", "").strip(), True)
                elif "07stinky bot:" in line: self.add_message_bubble(line.replace("07stinky bot:", "").strip(), False)

    def is_online(self):
        try:
            requests.get("https://www.google.com", timeout=2)
            return True
        except: return False

    def speak(self, text):
        if ANDROID_PLATFORM and hasattr(self, 'tts'):
            self.tts.speak(text, TTS.QUEUE_FLUSH, None)

    def update_system_info(self):
        Clock.schedule_once(lambda dt: self.update_system_info(), 60)

    def clear_chat(self):
        self.get_chat_screen_ids().chat_history.clear_widgets()

    def set_ai_mode(self, mode):
        self.current_mode = mode
        self.add_message_bubble(f"Bot switched to {mode} mode.", False)
        if self.menu_open: self.toggle_menu()

    def load_personality(self):
        self.personality = "" # Load from file if needed

if __name__ == '__main__':
    CyanixApp().run()
